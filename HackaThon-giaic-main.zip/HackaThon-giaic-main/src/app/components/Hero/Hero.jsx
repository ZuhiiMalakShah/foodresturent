import React from 'react'
import HeroClient from './hero.client'

const Hero = () => {
  return (
    <div>
      <HeroClient />
    </div>
  )
}

export default Hero